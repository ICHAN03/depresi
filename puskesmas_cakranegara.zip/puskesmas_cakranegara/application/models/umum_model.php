<?php
defined('BASEPATH') or exit('No direct script access allowed');

class umum_model extends CI_Model
{
    public function getUmum()
    {
        return $this->db->get('tbl_data_pasien')->result();
    }
    function create($objek)
    {
        $this->db->insert('tbl_poli_umum', $objek);
    }
    public function remove($id)
    {
        $this->db->delete('tbl_poli_umum', array('id' => $id));
    }
    public function get_id($id)
    {
        return $this->db->where('id', $id)->get('tbl_poli_umum')->row();
    }
    public function update($id, $objek)
    {
        return $this->db->where('id', $id)->update('tbl_poli_umum', $objek);
    }
}
