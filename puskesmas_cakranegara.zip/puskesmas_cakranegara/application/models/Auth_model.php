<?php
class Auth_model extends CI_Model
{
//  public function getAll(){
//      $this->db->select('*');
//      $this->db->from('tbl_data_pasien');
//      $this->db->join('tbl_poli_pasien', 'tbl_poli_pasien.iddtpasien = tbl_data_pasien.id');
//      $query = $this->db->get();
//      return $query->result();
//  }
    public function tambahDataUser()
    {
        $post = $this->input->post();
        $user=[
          'id' => uniqid(),
          'username' => $post['username'],
          'password' => password_hash($post['password'], PASSWORD_DEFAULT),
          'is_active' => 1
        ];

        $user_info = [
            'id' => uniqid(),
            'uid' => $user['id'],
            'nama_lengkap' => $post['name'],
            'email' => $post['email'],
            'photo' => 'default.jpg',
            'role' => $post['role'],
        ];

        if($post['role'] != 'admin')
            $user_info['role'] = 'dokter;' . $post['role'];
       
        $this->db->insert('users', $user);
        $this->db->insert('user_info', $user_info);
    }
//     public function pasien()
//     {
//         return $this->db->get('tbl_data_pasien')->result();
//     }
//     public function umum(){
//         return $this->db->get('tbl_poli_umum')->result();
//     }
//     public function mtbs(){
//         return $this->db->get('tbl_poli_mtbs')->result();
//     }
//     public function pkpr(){
//         return $this->db->get('tbl_poli_pkpr')->result();
//     }
//     public function kia(){
//         return $this->db->get('tbl_poli_kia')->result();
//     }   
//     public function gigi(){
//         return $this->db->get('tbl_poli_gigi')->result();
// }
}