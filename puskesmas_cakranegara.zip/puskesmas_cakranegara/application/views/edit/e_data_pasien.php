<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header " style="background-color: blue"></div>
            <div class="card-body">

                <form action="<?= site_url('admin/p_edit/') ?>" method="post">
                    <div class="form-group">
                        <label>Tanggal Kunjungan</label>
                        <input type="text" class="form-control" name="tanggal" value="<?= $pasien->tanggal_kunjungan; ?>" autocomplete="off">
                        <label>No Rekam Medis</label>
                        <input type="text" class="form-control" name="medis" value="<?= $pasien->no_rekam_medis; ?>"autocomplete="off"> 
                        <label>Nama Lengkap</label>
                        <input type="text" class="form-control" name="nama" value="<?= $pasien->nama_lengkap; ?>"autocomplete="off"> 
                        <label>No KK</label>
                        <input type="text" class="form-control" name="namakk" value="<?= $pasien->nokk; ?>" autocomplete="off"> 
                        <label>Nama Penanggung Jawab</label>
                        <input type="text" class="form-control" name="penanggungjawab" value="<?= $pasien->nama_penanggung_jawab; ?>"autocomplete="off"> 
                        <label>NIK</label>
                        <input type="text" class="form-control" name="NIK" value="<?= $pasien->NIK; ?>"autocomplete="off"> 
                        <label>Alamat</label>
                        <input type="text" class="form-control" name="alamat" value="<?= $pasien->alamat; ?>"autocomplete="off"> 
                        <label>Tanggal Lahir</label>
                        <input type="text" class="form-control" name="tgllahir" value="<?= $pasien->tanggal_lahir; ?>"autocomplete="off">
                        <label>Jenis Kelamin</label>
                            <select name="jk" autocomplete="off" class="form-control" value="<?= $pasien->jenis_kelamin; ?>">
                            <option value="Laki-Laki">Laki-Laki</option>
                            <option value="Perempuan">Perempuan</option>
                            </select>
                        <label>No Identitas</label>
                        <input type="text" class="form-control" name="noidentitas"value="<?= $pasien->no_identitas; ?>" autocomplete="off">
                        <label>Agama</label>
                            <select name="agama" autocomplete="off" class="form-control" value="<?= $pasein->agama; ?>">
                            <option value="Hindu">Hindu</option>
                            <option value="Islam">Islam</option>
                            <option value="Keristen">Kristen</option>
                            <option value="Buddha"> Buddha</option>
                            </select>
                        <label>Pendidikan</label>
                        <!-- <input type="text" class="form-control" name="pendidikan"value="<?= $pasien->pendidikan; ?>"
                            autocomplete="off"> -->
                            <select name="pendidikan" autocomplete="off" value="<?= $pasien->pendidikan; ?>"class="form-control">
                            <option value="Belu Sekolah">Belum Sekolah</option>
                            <option value="Taman Kanak-Kanak">TK</option>
                            <option value="Sekolah Dasar">SD</option>
                            <option value="sekolah Menengah Pertama">SMP</option>
                            <option value="Sekolah Menengah Atas">SMA</option>
                            <option value="Mahasiswa">Mahasiswa</option>
                            <option value="Mahasiswa">Berkerja</option>
                            <option value="Pengangguran">Pengangguran</option>
                            <option value="Pensiun">Pensiun</option> 
                            </select>
                        <label>Status Perkawinan</label>
                            <select name="perkawinan" autocomplete="off" class="form-control" value="<?= $pasien->status_perkawinan; ?>">
                                <option value="Belum Menikah">Belum Menikah</option>
                                <option value="Menikah">Menikah</option>
                            </select>
                        <label>No kartu JKN</label>
                        <input type="text" class="form-control" name="jkn"value="<?= $pasien->no_kartu_jkn; ?>"autocomplete="off">
                        <label>Cara Bayar</label>
                            <select name="bayar" id="" autocomplete="off" class="form-control" value="<?= $pasien->cara_pembayaran; ?>">
                                <option value="BPJS">BPJS</option>
                                <option value="Tunai">Tunai</option>

                             </select>
                    </div>
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?= $pasien->id; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>

            </div>
        </div>
    </div>
</div>
</div>