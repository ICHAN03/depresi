
<!DOCTYPE HTML>
<html>
<head>
<script type="text/javascript">
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	<?php 
		$this->db->select('tanggal_kunjungan');
		$dataUmum = $this->db->get('tbl_poli_umum')->result();
		// var_dump($data);
		// die;
	?>
	theme: "light1", // "light2", "dark1", "dark2"
	animationEnabled: false, // change to true		
	title:{
		text: "Laporan Data Pasien"
	},
	data: [
	{
		// Change type to "bar", "area", "spline", "pie",etc.
		type: "column",
		 dataPoints: [
		// 	{ label: "apple",  y: 10  },
		// 	{ label: "orange", y: 15  },
		// 	{ label: "banana", y: 25  },
		// 	{ label: "mango",  y: 30  },
		// 	{ label: "grape",  y: 28  }
		<?php
			foreach ($dataUmum as $k => $v) {
				echo '{label: "Y", y: '.$v->tanggal_kunjungan.' },';
				// echo '{label: "Y", y: '.$v->jantung.'}, {label: "H",h:'.$v->tensi.'}';
			}
		?>
		]
		//dataPoints: 
		//
	}
	]
});
chart.render();

}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"> </script>
</body>
</html>