<!DOCTYPE html>
<html>

<head>
    <title>Export Data Ke Excel Dengan PHP - www.malasngoding.com</title>
</head>

<body>
    <style type="text/css">
    body {
        font-family: sans-serif;
    }

    table {
        margin: 20px auto;
        border-collapse: collapse;
    }

    table th,
    table td {
        border: 1px solid #3c3c3c;
        padding: 3px 8px;

    }

    a {
        background: blue;
        color: #fff;
        padding: 8px 10px;
        text-decoration: none;
        border-radius: 2px;
    }
    </style>
    <center>
        <h1>DINAS KESEHATAN KOTA MATARAM</h1>
            <h1>PUSKEMAS CAKRANEGARA</h1>
         <h1>LAPORAN KUJUNGAN DATA PASIEN</h1>
     <h1>_________________________________</h1>

    </center>

    <center>
        <a target="_blank" href="<?= site_url() . '/detail/detailPasien' ?>">EXPORT KE EXCEL</a>
    </center>

    <table>
    <tr>
         <th>No</th>
         <th>Tangaal Kunjungan</th>
         <th>No Rekam Medis</th>
         <th>Nama Lengkap</th>
         <th>Nama KK</th>
         <th>Nama Penangung Jawab</th>
         <th>NIK</th>
         <th>Alamat</th>
         <th>Tanggal Lahir</th>
         <th>Jenis Kelamin</th>
         <th>No Identitas</th>
         <th>Agama</th>
         <th>Pendidikan</th>
         <th>Status Perkawinan</th>
         <th>No Kartu JKN</th>
         <th>Unit Pelayanan</th>
         <th>Cara Bayar</th>
            
     </tr>
        <tr>
            <td>1</td>
            <td>Sulaiman</td>
            <td>Jakarta</td>
            <td>0829121223</td>
        </tr>
        
    </table>
</body>

</html>