      

<!-- Page Heading -->
<!-- <h1 class="h3 mb-4 text-gray-900"><?=$title?></h1> -->

<!-- /.container-fluid -->

<!-- </div> -->
<!-- End of Main Content -->

 <!-- Begin Page Content -->
 <div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
  <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-fw fa-tachometer-alt"></i> Generate Report</a> -->
</div>


<!-- <div class="row"> -->
    <!-- Illustrations -->
  
    <!-- <div class="card shadow mb-2">
      <div class="card-header py-2"> -->
        <!-- <h6 class="m-0 font-weight-bold text-primary">Visi</h6> -->
        <!-- <body> -->
        <!-- </div> -->
        
      <div class="card-body">
        <div class="text-center">
          <!-- <img class="img-fluid px-0 px-sm-0 mt-0 mb-0" style="width: 25rem;" src="img/undraw_posting_photo.svg" alt=""> -->
        </div>
        <center>
                <td>SELAMAT DATANG DI WEBSET PUSKESMAS CAKRANEGARA</td>
        </center>
       
      </div>
    </div>
            
        <!-- </body> -->
     

<!-- Content Row -->
<div class="row">

  <!-- Earnings (Monthly) Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-primary shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">PENDAFTARAN</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"></div>
          </div>
          <div class="col-auto">
            <i class="far fa-fw fa-user fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Earnings (Monthly) Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-success shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Data Pasien</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"></div>
          </div>
          <div class="col-auto">
            <i class="fas fa_fw fa-database fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Earnings (Monthly) Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-info shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">POLI</div>
            <div class="row no-gutters align-items-center">
              <div class="col-auto">
                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">50%</div>
              </div>
              <div class="col">
                <div class="progress progress-sm mr-2">
                  <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-auto">
            <i class="fas fa-fw fa-folder fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Pending Requests Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-warning shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Charts</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"></div>
          </div>
          <div class="col-auto">
            <i class="fas fa-fw fa-chart-area fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Content Row -->




<!-- Content Row -->
<div class="row">


    <!-- Illustrations -->
  
    <div class="card shadow mb-2">
      <div class="card-header py-2">
        <h6 class="m-0 font-weight-bold text-primary">Visi</h6>
      </div>
      <div class="card-body">
        <div class="text-center">
          <img class="img-fluid px-1 px-sm-2 mt-1 mb-1" style="width: 25rem;" src="img/undraw_posting_photo.svg" alt="">
        </div>
        <p>Terbentuknya masyarakat sehat yang mandiri di wilayah kerja Puskesmas Cakranegara tahun 2021</p>
      </div>
    </div>

    <!-- Approach -->
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Misi</h6>
      </div>
      <div class="card-body">
        
        <p class="mb-0">1. Meningkatkan sumber daya manusia dan kualitas manajemen</p>
        <p class="mb-0">2. Memberikan pelayanan kesehatan yang professioal dan integrasi</p>
        <p class="mb-0">3. Meningkatkan derajat kesehatan melalui pemberdayaan masyarakat</p>

      </div>
      
    </div>

    </div>
          </div>
          <div class="card shadow mb-2">
      <div class="card-header py-2">
        <h6 class="m-0 font-weight-bold text-primary">Visi</h6>
      </div>
      <div class="card-body">
        <div class="text-center">
          <img class="img-fluid px-1 px-sm-2 mt-1 mb-1" style="width: 25rem;" src="img/undraw_posting_photo.svg" alt="">
        </div>
        <p>Terbentuknya masyarakat sehat yang mandiri di wilayah kerja Puskesmas Cakranegara tahun 2021</p>
      </div>
    </div>

        </div>
        <!-- /.container-fluid -->

      </div>