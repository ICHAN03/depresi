<div class="card mb-3" style="max-width: 440px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="<?= base_url('assets/img/profile/') .  $this->session->userdata('photo'); ?>" class="card-img" >
    </div>
    <div class="col-md-8">
      <div class="card-body">
      <h5 class="card-title"><?=  $this->session->userdata('nama_lengkap');?></h5>
        <p class="card-text"><?= $this->session->userdata('email');?></p>
        <p class="card-text"><small class="text-muted">Pengunjung Webset <?=date ('d F Y', time($this->session->userdata('created_at')));?></small></p>
      </div>
      <button type="submit" class="btn btn-primary btn-user btn-block">
      EDIT
  </button>
    </div>
  </div>

</div>