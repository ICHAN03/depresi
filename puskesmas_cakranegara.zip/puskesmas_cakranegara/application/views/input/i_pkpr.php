

<!-- Modal Tambah Data -->

<div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="TambahLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"></span>
                </button>
            </div>

            <form action="<?= site_url('admin/tambahPkpr') ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">

                    <div class="form-group">
                        <label>ID Poli</label>
                        <select class="custom-select" onfocus="this.size=1" id="pasien" name="pasien">
                                <div class="test">
                                    <option>-Pilih-</option>
                                    <?php foreach ($pasien as $key) : ?>
                                    <option value="<?= $key->id ?>"><?= $key->nama_lengkap; ?></option>
                                    <?php endforeach; ?>
                                </div>
                            </select>
                        </div>
                        <!-- <input type="text" class="form-control" name="IDPoli" autocomplete="off"> -->
                        <label>Nama</label>
                        <input type="text" class="form-control" name="nama" autocomplete="off">
                        <label>Anamenesa</label>
                        <input type="text" class="form-control" name="anamenesa" autocomplete="off">
                        <label>Physic Diagnostic</label>
                        <input type="text" class="form-control" name="diagnostic" autocomplete="off">
                        <label>Tensi</label>
                        <input type="text" class="form-control" name="tensi" autocomplete="off">
                        <label>Nadi</label>
                        <input type="text" class="form-control" name="nadi" autocomplete="off">
                        <label>Suhu</label>
                        <input type="text" class="form-control" name="suhu" autocomplete="off">
                        <label>Laju Pernafasan</label>
                        <input type="text" class="form-control" name="laju" autocomplete="off">
                        <label>Tinggi Badan</label>
                        <input type="text" class="form-control" name="tinggi_badan" autocomplete="off">
                        <label>Berat Badan</label>
                        <input type="text" class="form-control" name="berat_badan" autocomplete="off">
                        <label>Tingkat Kesadaran</label>
                        <input type="text" class="form-control" name="tingkat_kesadaran" autocomplete="off">
                        <label>Kepala</label>
                        <input type="text" class="form-control" name="kepala" autocomplete="off">
                        <label>Jantung</label>
                        <input type="text" class="form-control" name="jantung" autocomplete="off">
                        <label>Paru-Paru</label>
                        <input type="text" class="form-control" name="paru_paru" autocomplete="off">
                        <label>Perut</label>
                        <input type="text" class="form-control" name="perut" autocomplete="off">
                        <label>Adema</label>
                        <input type="text" class="form-control" name="adema" autocomplete="off">
                        <label>ICD_X</label>
                        <input type="text" class="form-control" name="icd" autocomplete="off">
                        <label>Planing</label>
                        <input type="text" class="form-control" name="planing" autocomplete="off">
                        <label>Tanggal Kunjungan</label>
                        <input type="date" class="form-control" name="tanggal" autocomplete="off">
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" name="insertdata" class="btn btn-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- DataTales Example -->
<h1 class="h3 mb-2 text-gray-800">POLIKLINIK PKPR</h1>
<!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p> -->

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <!-- <h6 class="m-0 font-weight-bold text-primary">Tambah</h6> -->
    <button type="button" class="btn btn-warning  mb-3" data-toggle="modal" data-target="#tambah"><i
                    class="fas fa-fw fa-plus-circle"></i>Tambah</button>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID Poli</th>
                        <th>Nama</th>
                        <th>Anamenesa</th>
                        <th>Physic Diagnostic</th>
                        <th>Tensi</th>
                        <th>Nadi</th>
                        <th>Suhu</th>
                        <th>Laju Pernafasan</th>
                        <th>Tinggi Badan</th>
                        <th>Berat Badan</th>
                        <th>Tingkat Kesadaran</th>
                        <th>Kepala Leher</th>
                        <th>jantung</th>
                        <th>Paru-Paru</th>
                        <th>Perut</th>
                        <th>Adema</th>
                        <th>ICD_X</th>
                        <th>Planing</th>
                        <th>Tangaal Kunjungan</th>

                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i= 1; ?>
                    <?php foreach ($pkpr as $apa): ?>
                    <tr>
                    <td><?=$i++;?></td>
                <td><?= $apa->iddtpasien ?></td>
                <td><?= $apa->nama?></td>
                <td><?= $apa->anamnesa?></td>
                <td><?= $apa->physic_diagnostic ?></td>
                <td><?= $apa->tensi ?></td>
                <td><?= $apa->nadi ?></td>
                <td><?= $apa->suhu ?></td>
                <td><?= $apa->laju_pernafasan ?></td>
                <td><?= $apa->tinggi_badan ?></td>
                <td><?= $apa->berat_badan ?></td>
                <td><?= $apa->tingkat_kesadaran ?></td>
                <td><?= $apa->kepala_leher ?></td>
                <td><?= $apa->jantung ?></td>
                <td><?= $apa->paru_paru ?></td>
                <td><?= $apa->perut ?></td>
                <td><?= $apa->adema ?></td>
                <td><?= $apa->ICD_X ?></td>
                <td><?= $apa->planing ?></td>
                <td><?= $apa->tanggal_kunjungan ?></td>

                        <td>
                        <a href="<?= site_url('admin/detailPkpr/'.$apa->id) ?>" class="btn btn-default"><i
                                    class="far fa-fw fa-file"></i></a>
                            <a href="<?= site_url('') ?>" class="btn btn-warning"><i
                                    class="far fa-fw fa-edit"></i></a>
                            <a onclick="return confirm ('yakin?');"
                                href="<?= site_url('admin/hapusPkpr/' .$apa->id ) ?>" class="btn btn-danger"><i
                                    class="fas fa-fw fa-trash-alt"></i></a>
                        </td>
                    </tr>
                    <?php endforeach ;?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
