<?php
defined('BASEPATH') or exit('No direct script accesss allowed');

class coba extends CI_Controller
{
    public function __contruct(){
        parent::__contruct();
        $this->load->model('Auth_model');

    }
    public function index()
    {
        $data['title'] = 'Dashboard';
        
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('admin/icoba',$data);
        $this->load->view('templates/footer');
    }
}