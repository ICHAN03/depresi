<?php
defined('BASEPATH') or exit('No direct script accesss allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Auth_model');
        $this->load->library('form_validation');
    }
    public function index()
    {
        if($this->session->userData('email')){
            redirect('user');
        }
        $this->form_validation->set_rules('user', 'User', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        
        if ($this->form_validation->run() == false) {
        $data['title'] = 'Halaman Login';
        $this->load->view('templates/auth_header', $data);
        $this->load->view('auth/login');
        $this->load->view('templates/auth_footer');
    } else {
        $this->_login();
    }
}
private function _login()
{
    $user = $this->input->post('user');
    $password = $this->input->post('password');
    
    $user_data = $this->db->select('users.username, users.password, users.is_active, user_info.*', FALSE)
                ->where('users.username', $user)
                ->or_where('user_info.email', $user)
                ->from('users')
                ->join('user_info', 'users.id = user_info.uid', 'INNER', FALSE)
                ->get()->row();

    if(empty($user_data)){
        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email atau Username <b>' .  $user . '</b> tidak ditemukan</div>');
        redirect('Auth');
    }

    if($user_data->is_active != 1){
        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Akun dengan username <b>' . $user_data->username . '</b> Belum diaktifkan</div>');
        redirect('Auth');
    }

    if(password_verify($password, $user_data->password)){
        $data = [
            'username' => $user_data->username,
            'nama_lengkap' => $user_data->nama_lengkap,
            'photo' => $user_data->photo,
            'email' => $user_data->email,
            'role' => $user_data->role,
            'poli' => NULL,
            'is_active' => $user_data->is_active,
            'created_at' => $user_data->created_at,
        ];

        if($user_data->role != 'admin'){
            $data['role'] = explode(';', $user_data->role)[0];
            $data['poli'] = explode(';', $user_data->role)[1];
        }
           
        $this->session->set_userdata($data);

        if($user_data->role == 'admin')
            redirect('admin');
        else
            redirect('user');

    }else {
        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Pasword untuk user <b>' .  $user . '</b> salah!</div>');
        redirect('Auth');
    }


    // $user = $this->db->get_where('user', ['email' => $email])->row_array();
    // // cek user ada apa tidak
    // if ($user) {
    //     if ($user['is_active'] == 1) {
    //         // cek password
    //         if (password_verify($password, $user['password'])) {
    //             $data = [
    //                 'email' => $user['email'],
    //                 'role_id' => $user['role_id']
    //             ];
    //             $this->session->set_userdata($data);
    //             if($user['role_id']==1){
    //                 redirect('admin');
    //             }else{
    //                 redirect('user');
    //             }
    //         } else {
    //             $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
    //             Wrong password!
    //           </div>');
    //             redirect('Auth');
    //         }
    //     } else {
    //         $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
    //         This email has not been activated!
    //       </div>');
    //         redirect('Auth');
    //     }
    // } else {
    //     $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
    //     Email is not registered!
    //   </div>');
    //     redirect('Auth');
    // }
}

    public function registrasi()
    {
        if($this->session->userdata('email')){
            redirect('user');
        }
        
        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user_info.email]',[
            'is_unique' => 'this email has already registrasi'
        ]);
        $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[users.username]',[
            'is_unique' => 'this username has already registrasi'
        ]);

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Halaman Registrasi';
            $this->load->view('templates/auth_header', $data);
            $this->load->view('auth/registrasi');
            $this->load->view('templates/auth_footer');
        } else {            
            $this->Auth_model->tambahDataUser();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Akun Telah Dibuat
          </div>');
            redirect('Auth');
        }
    }

    public function logout()
    {
        $this->session->unset_userdata();
        $this->session->sess_destroy();
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
        Sudah Keluar dari Aplikasi
      </div>');
        redirect('Auth');
        
    }
    
    }

