<?php
defined('BASEPATH') or exit('No direct script accesss allowed');

class admin extends CI_Controller
{
    public function __contruct(){
        parent::__contruct();
        $this->load->model('Auth_model');

    }
    public function index()
    {
        $data['title'] = 'Dashboard';
        
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('admin/index',$data);
        $this->load->view('templates/footer');
    }

    public function profile()
    {
        $data['title'] = 'PROFIL';
        
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('admin/profil',$data);
        $this->load->view('templates/footer');
    }
    public function pendaftaran()
    {
        $data['title'] = 'Data Pasien';
        // $data['pasien'] = $this->Auth_model->getUmum();
        $data['pendaftaran'] = $this->db->get('tbl_data_pasien')->result();
        
        
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_pendaftaran');
        $this->load->view('templates/footer');
    }
    public function tambahPendaftaran()
    {

        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->Auth_model->getUmum();
        $data['pendaftaran'] = $this->db->get('tbl_data_pasien')->result();
        $tglkunj =$this->input->post('tanggal');
        $rekam = $this->input->post('medis');
        $nma = $this->input->post('nama');
        $nkk = $this->input->post('nokk');
        $pjawab = $this->input->post('penangungjawab');
        $nik = $this->input->post('NIK');
        $alamat = $this->input->post('alamat');
        $tglL = $this->input->post('tgllahir');
        $umur = $this->input->post('umur');
        $jk = $this->input->post('jk');
        // $noIden = $this->input->post('noidentitas');
        $agama = $this->input->post('agama');
        $pendidikan = $this->input->post('pendidikan');
        $perkawinan = $this->input->post('perkawinan');
        // $jkn = $this->input->post('jkn');
        // $unit = $this->input->post('unit');
        $byr = $this->input->post('bayar');
      
        // $meong = $this->input->post('namakk');

        $objek = [
           'tanggal_kunjungan'=>$tglkunj,
        //    'tanggal_kunjungan'=> time(),
           'no_rekam_medis' => $rekam,
            'nama_lengkap'=>$nma,
             'nokk'=>$nkk,
             'nama_penanggung_jawab' => $pjawab,
             'NIK' => $nik,
             'alamat' => $alamat,
             'tanggal_lahir' => $tglL,
             'umur' =>$umur,
             'jenis_kelamin' => $jk,
            //  'no_identitas' => $noIden,
             'agama' => $agama,
             'pendidikan' => $pendidikan,
             'status_perkawinan' => $perkawinan,
            //  'no_kartu_jkn' => $jkn,
            //  'unit_pelayanan' => $unit,
             'cara_pembayaran' => $byr,


        ];
        $this->db->insert('tbl_data_pasien',$objek);
    //    var_dump( $this->db->insert('tbl_data_pasien',$objek));
    //    die();
        
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_pendaftaran');
        $this->load->view('templates/footer');
        redirect('admin/pasien','refresh');
    }
    public function hapusPendaftaran($id){
        $this->db->delete('tbl_data_pasien',array('id' => $id));
        redirect('admin/pasien','refresh');
    }
    public function updateP ($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
       $data['pendaftaran'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
        // var_dump($data['pasien']);
        // die;
            

       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('edit/e_pendaftaran');
       $this->load->view('templates/footer');
    }
    public function p_editPendaftaran(){
        $id = $this->input->post('id');
        $tglkunj =$this->input->post('tanggal');
        $rekam = $this->input->post('medis');
        $nma = $this->input->post('nama');
        $nkk = $this->input->post('nokk');
        $pjawab = $this->input->post('penanggungjawab');
        $nik = $this->input->post('NIK');
        $alamat = $this->input->post('alamat');
        $tglL = $this->input->post('tgllahir');
        $jk = $this->input->post('jk');
        // $noIden = $this->input->post('noidentitas');
        $agama = $this->input->post('agama');
        $pendidikan = $this->input->post('pendidikan');
        $perkawinan = $this->input->post('perkawinan');
        $jkn = $this->input->post('jkn');
        $byr = $this->input->post('bayar');
        $objek = array(
            'id'=>$id,
            'tanggal_kunjungan'=>$tglkunj,
            //    'tanggal_kunjungan'=> time(),
               'no_rekam_medis' => $rekam,
                'nama_lengkap'=>$nma,
                 'nokk'=>$nkk,
                 'nama_penanggung_jawab' => $pjawab,
                 'NIK' => $nik,
                 'alamat' => $alamat,
                 'tanggal_lahir' => $tglL,
                 'jenis_kelamin' => $jk,
                //  'no_identitas' => $noIden,
                 'agama' => $agama,
                 'pendidikan' => $pendidikan,
                 'status_perkawinan' => $perkawinan,
                //  'no_kartu_jkn' => $jkn,
                 'cara_pembayaran' => $byr,);
            $this->db->where('id',$id)->update('tbl_data_pasien',$objek);
            redirect('admin/pasien', 'refresh');
        
    } 
  
   
    public function pasien()
    {
        $data['title'] = 'Data Pasien';
        // $data['pasien'] = $this->Auth_model->getUmum();
        $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
        
        
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_data_pasien');
        $this->load->view('templates/footer');
    }
    public function tambahPasien()
    {

        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->Auth_model->getUmum();
        $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
        $tglkunj =$this->input->post('tanggal');
        $rekam = $this->input->post('medis');
        $nma = $this->input->post('nama');
        $nkk = $this->input->post('nokk');
        $pjawab = $this->input->post('penanggungjawab');
        $nik = $this->input->post('NIK');
        $alamat = $this->input->post('alamat');
        $tmptL = $this->input->post('tmptlahir');
        $tglL = $this->input->post('tgllahir');
        $desa = $this->input->post('desa');
        $kota = $this->input->post('kota');
        $umur = $this->input->post('umur');
        $jk = $this->input->post('jk');
        $noIden = $this->input->post('noidentitas');
        $agama = $this->input->post('agama');
        $pendidikan = $this->input->post('pendidikan');
        $perkawinan = $this->input->post('perkawinan');
        $jkn = $this->input->post('jkn');
        $unit = $this->input->post('unit');
        $byr = $this->input->post('bayar');
      
        // $meong = $this->input->post('namakk');

        $objek = [
           'tanggal_kunjungan'=>$tglkunj,
        //    'tanggal_kunjungan'=> time(),
           'no_rekam_medis' => $rekam,
            'nama_lengkap'=>$nma,
             'nokk'=>$nkk,
             'nama_penanggung_jawab' => $pjawab,
             'NIK' => $nik,
             'alamat' => $alamat,
             'tempat_lahir' => $tmptL,
             'tanggal_lahir' => $tglL,
             'desa_kelurahan' => $desa,
             'kabupaten_kota' => $kota,
             'umur' =>$umur,
             'jenis_kelamin' => $jk,
             'no_identitas' => $noIden,
             'agama' => $agama,
             'pendidikan' => $pendidikan,
             'status_perkawinan' => $perkawinan,
             'no_kartu_jkn' => $jkn,
             'unit_pelayanan' => $unit,
             'cara_pembayaran' => $byr,


        ];
        $this->db->insert('tbl_data_pasien',$objek);
    //    var_dump( $this->db->insert('tbl_data_pasien',$objek));
    //    die();
        
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_data_pasien');
        $this->load->view('templates/footer');
        redirect('admin/pasien','refresh');
    }
    public function hapusPasien($id){
        $this->db->delete('tbl_data_pasien',array('id' => $id));
        redirect('admin/pasien','refresh');
    }
    public function update ($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
       $data['pasien'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
        // var_dump($data['pasien']);
        // die;
            

       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('edit/e_data_pasien');
       $this->load->view('templates/footer');
    }
    public function p_edit(){
        $id = $this->input->post('id');
        $tglkunj =$this->input->post('tanggal');
        $rekam = $this->input->post('medis');
        $nma = $this->input->post('nama');
        $nkk = $this->input->post('nkk');
        $pjawab = $this->input->post('penanggungjawab');
        $nik = $this->input->post('NIK');
        $alamat = $this->input->post('alamat');
        $tglL = $this->input->post('tgllahir');
        $jk = $this->input->post('jk');
        $noIden = $this->input->post('noidentitas');
        $agama = $this->input->post('agama');
        $pendidikan = $this->input->post('pendidikan');
        $perkawinan = $this->input->post('perkawinan');
        $jkn = $this->input->post('jkn');
        $byr = $this->input->post('bayar');
        $objek = array(
            'id'=>$id,
            'tanggal_kunjungan'=>$tglkunj,
            //    'tanggal_kunjungan'=> time(),
               'no_rekam_medis' => $rekam,
                'nama_lengkap'=>$nma,
                 'nokk'=>$nkk,
                 'nama_penanggung_jawab' => $pjawab,
                 'NIK' => $nik,
                 'alamat' => $alamat,
                 'tanggal_lahir' => $tglL,
                 'jenis_kelamin' => $jk,
                 'no_identitas' => $noIden,
                 'agama' => $agama,
                 'pendidikan' => $pendidikan,
                 'status_perkawinan' => $perkawinan,
                 'no_kartu_jkn' => $jkn,
                 'cara_pembayaran' => $byr,);
            $this->db->where('id',$id)->update('tbl_data_pasien',$objek);
            redirect('admin/pasien', 'refresh');
        
    } 
    public function detailPasien($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['detailPasien'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
        // var_dump($data['umum']);
        // die;
            
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('detail/detailPasien');
       $this->load->view('templates/footer');
    }
    // public function detailUmum2($id){
    //     $data['title'] = 'Edit Data';
    //     $data['user']= $this->db->get_where('user',['email'=> 
    //     $this->session->userdata('email')])->row_array();
    //     // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
    //    $data['detail'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
    //     // var_dump($data['umum']);
    //     // die;
            
    //    $this->load->view('templates/header');
    //    $this->load->view('templates/sidebar');
    //    $this->load->view('templates/topbar',$data);
    //    $this->load->view('detail/detailUmum');
    //    $this->load->view('templates/footer');
    // }
    // public function grafikPasien()
    // {
    //     $data['title'] = 'Edit Data';
    //         $data['user']= $this->db->get_where('user',['email'=> 
    //         $this->session->userdata('email')])->row_array();
    //         // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
    //     //    $data['detailPasien'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
    //         // var_dump($data['umum']);
    //         // die;
                
    //        $this->load->view('templates/header');
    //        $this->load->view('templates/sidebar');
    //        $this->load->view('templates/topbar',$data);
    //        $this->load->view('grafik/grafik');
    //        $this->load->view('templates/footer');
    //     }
    public function grafikPasien()
    {
        $data['title'] = 'Edit Data';
            $data['user']= $this->db->get_where('user',['email'=> 
            $this->session->userdata('email')])->row_array();
            // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
        //    $data['detailPasien'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
            // var_dump($data['umum']);
            // die;
                
           $this->load->view('templates/header');
           $this->load->view('templates/sidebar');
           $this->load->view('templates/topbar',$data);
           $this->load->view('grafik/grafikPasien');
           $this->load->view('templates/footer');
        }
    public function umum()
    {
        $data['title'] = 'POLIKLINIK UMUM';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['umum'] = $this->umum_model->getUmum();
        $data['umum'] = $this->db->get('tbl_poli_umum')->result();
        $data['pasien'] = $this->db->get('tbl_data_pasien')->result();     
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_umum',$data);
        $this->load->view('templates/footer');
    }

   
    public function tambahUmum()
    {
        $data['umum'] = $this->db->get('tbl_poli_umum')->result();
        $idpoli = $this->input->post('pasien');
        $nma = $this->input->post('nama');
        $anamnesa = $this->input->post('anamnesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');
        $objek = [
           
            'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamnesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj,


        ];
        $this->db->insert('tbl_poli_umum',$objek);
        
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_data_pasien');
        $this->load->view('templates/footer');
        redirect('admin/umum','refresh');
    }
    public function hapusUmum($id){
        $this->db->delete('tbl_poli_umum',array('id' => $id));
        redirect('admin/umum');
        // var_dump( $this->db->delete('tbl_poli_gigi',array('id' => $id)));
        // die;
    }
    public function editUmum($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_umum')->row();
        // var_dump($data['umum']);
        // die;
            
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('edit/e_umum',$data);
       $this->load->view('templates/footer');
    }
    public function p_editU(){
       
        $id = $this->input->post('id');
        $idpoli = $this->input->post('iddtpasien');
        $nma = $this->input->post('nama');
        $anamenesa = $this->input->post('anamnesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');
        $objek = array(
            // 'id'=>$id,
            // 'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamenesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj);


              $this->db->where('id',$id)->update('tbl_poli_umum',$objek);
              $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
            redirect('admin/umum', 'refresh');
    } 


    public function cariUmum(){
       
        $keyword = $this->input->post('keyword');
        $data['cari']=$this->db->get($keyword);
        $this->load->view('cari',$data);
    
    }
    
    public function detailUmum($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_umum')->row();
        // var_dump($data['umum']);
        // die;
            
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('detail/detailUmum');
       $this->load->view('templates/footer');
    }

     public function grafikUmum()
    {
        $data['title'] = 'Edit Data';
            $data['user']= $this->db->get_where('user',['email'=> 
            $this->session->userdata('email')])->row_array();
            // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
        //    $data['detailPasien'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
            // var_dump($data['umum']);
            // die;
                
           $this->load->view('templates/header');
           $this->load->view('templates/sidebar');
           $this->load->view('templates/topbar',$data);
           $this->load->view('grafik/grafikUmum');
           $this->load->view('templates/footer');
        }
    public function mtbs()
    {
        $data['title'] = 'POLIKLINIK MTBS';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['umum'] = $this->umum_model->getUmum();
        $data['mtbs'] = $this->db->get('tbl_poli_mtbs')->result();
        $data['pasien'] = $this->db->get('tbl_data_pasien')->result();     

        
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_mtbs',$data);
        $this->load->view('templates/footer');
    } 
    public function tambahMtbs()
    {
        $data['mtbs'] = $this->db->get('tbl_poli_mtbs')->result();
        $idpoli = $this->input->post('pasien');
        $nma = $this->input->post('nama');
        $anamenesa = $this->input->post('anamenesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');
        $objek = [  
            'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamenesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj,


        ];
        $this->db->insert('tbl_poli_mtbs',$objek);
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_mtbs');
        $this->load->view('templates/footer');
        redirect('admin/mtbs','refresh');
    }
   
    public function hapusMtbs($id){
        $this->db->delete('tbl_poli_mtbs',array('id' => $id));
        redirect('admin/mtbs');
        // var_dump( $this->db->delete('tbl_poli_gigi',array('id' => $id)));
        // die;
    }
    public function editMtbs($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_mtbs')->row();
        // var_dump($data['umum']);
        // die;
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('edit/e_mtbs');
       $this->load->view('templates/footer');
    }
    public function p_editM(){
        $id = $this->input->post('id');
        $idpoli = $this->input->post('iddtpasien');
        $nma = $this->input->post('nama');
        $anamenesa = $this->input->post('anamenesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');
        $objek = array(
            'id'=>$id,
            'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamenesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj,);

            $this->db->where('id',$id)->update('tbl_poli_mtbs',$objek);
            redirect('admin/mtbs', 'refresh');
        
    } 
    public function detailMtbs($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_mtbs')->row();
        // var_dump($data['umum']);
        // die;
            
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('detail/detailMtbs');
       $this->load->view('templates/footer');
    }
     public function grafikMtbs()
    {
        $data['title'] = 'Edit Data';
            $data['user']= $this->db->get_where('user',['email'=> 
            $this->session->userdata('email')])->row_array();
            // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
        //    $data['detailPasien'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
            // var_dump($data['umum']);
            // die;
                
           $this->load->view('templates/header');
           $this->load->view('templates/sidebar');
           $this->load->view('templates/topbar',$data);
           $this->load->view('grafik/grafikMtbs');
           $this->load->view('templates/footer');
        }
    public function pkpr()
    {
        $data['title'] = 'POLIKLINIK PKPR';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['umum'] = $this->umum_model->getUmum();
        $data['pkpr'] = $this->db->get('tbl_poli_pkpr')->result();
        $data['pasien'] = $this->db->get('tbl_data_pasien')->result();     

        
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_pkpr',$data);
        $this->load->view('templates/footer');
    }
    public function tambahPkpr()
    {
        $data['pkpr'] = $this->db->get('tbl_poli_pkpr')->result();
    
        $idpoli = $this->input->post('pasien');
        $nma = $this->input->post('nama');
        $anamenesa = $this->input->post('anamenesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');
        $objek = [
           
            'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamenesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj,


        ];
        $this->db->insert('tbl_poli_pkpr',$objek);
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_data_pasien');
        $this->load->view('templates/footer');
        redirect('admin/pkpr','refresh');
    }
    public function hapusPkpr($id){
        $this->db->delete('tbl_poli_pkpr',array('id' => $id));
        redirect('admin/pkpr');
        // var_dump( $this->db->delete('tbl_poli_gigi',array('id' => $id)));
        // die;
    }
    public function editPkpr($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_pkpr')->row();
        // var_dump($data['umum']);
        // die;
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('edit/e_umum');
       $this->load->view('templates/footer');
    }
    public function p_editP(){
       
        $id = $this->input->post('id');
        $idpoli = $this->input->post('iddtpasien');
        $nma = $this->input->post('nama');
        $anamenesa = $this->input->post('anamenesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');
        $objek = array(
            'id'=>$id,
            'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamenesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj,);

            $this->db->where('id',$id)->update('tbl_poli_pkpr',$objek);
            redirect('admin/pkpr', 'refresh');
        
    } 
    public function detailPkpr($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_pkpr')->row();
        // var_dump($data['umum']);
        // die;
            
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('detail/detailPkpr');
       $this->load->view('templates/footer');
    }
    public function kia()
    {
        $data['title'] = 'POLIKLINIK KIA';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['umum'] = $this->umum_model->getUmum();
        $data['kia'] = $this->db->get('tbl_poli_kia')->result();
        $data['pasien'] = $this->db->get('tbl_data_pasien')->result();     
        
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_kia',$data);
        $this->load->view('templates/footer');
    }
    
    public function tambahKia()
    {
        $data['kia'] = $this->db->get('tbl_poli_kia')->result();
        
        $idpoli = $this->input->post('pasien');
        $nma = $this->input->post('nama');
        $anamenesa = $this->input->post('anamenesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');
        $objek = [
           
            'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamenesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj,

        ];
        $this->db->insert('tbl_poli_kia',$objek);
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_data_pasien');
        $this->load->view('templates/footer');
        redirect('admin/kia','refresh');
    }
    public function hapusKia($id){
        $this->db->delete('tbl_poli_kia',array('id' => $id));
        redirect('admin/kia');
        // var_dump( $this->db->delete('tbl_poli_gigi',array('id' => $id)));
        // die;
    }
    public function editKia($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_kia')->row();
        // var_dump($data['umum']);
        // die;    

       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('edit/e_umum');
       $this->load->view('templates/footer');
    }
    public function p_editK(){
       
        $id = $this->input->post('id');
        $idpoli = $this->input->post('iddtpasien');
        $nma = $this->input->post('nama');
        $anamenesa = $this->input->post('anamenesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');
        $objek = array(
            'id'=>$id,
            'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamenesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj,);

            $this->db->where('id',$id)->update('tbl_poli_kia',$objek);
            redirect('admin/kia', 'refresh');
        
    } 
    public function detailKia($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_kia')->row();
        // var_dump($data['umum']);
        // die;
            
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('detail/detailKia');
       $this->load->view('templates/footer');
    }
    
    public function grafikKia()
    {
        $data['title'] = 'Edit Data';
            $data['user']= $this->db->get_where('user',['email'=> 
            $this->session->userdata('email')])->row_array();
            // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
        //    $data['detailPasien'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
            // var_dump($data['umum']);
            // die;
                
           $this->load->view('templates/header');
           $this->load->view('templates/sidebar');
           $this->load->view('templates/topbar',$data);
           $this->load->view('grafik/GrafikKia');
           $this->load->view('templates/footer');
        }
    public function gigi()
    {
        $data['title'] = 'POLIKLINIK GIGI';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['umum'] = $this->umum_model->getUmum();
        $data['gigi'] = $this->db->get('tbl_poli_gigi')->result();
        $data['pasien'] = $this->db->get('tbl_data_pasien')->result();     

        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_gigi',$data);
        $this->load->view('templates/footer');
    }
    public function tambahGigi()
    {
        $data['mtbs'] = $this->db->get('tbl_poli_gigi')->result();
       
        $idpoli = $this->input->post('pasien');
        $nma = $this->input->post('nama');
        $anamenesa = $this->input->post('anamenesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');

        $objek = [
           
            'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamenesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj,


        ];
        $this->db->insert('tbl_poli_gigi',$objek);
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar',$data);
        $this->load->view('input/i_data_pasien');
        $this->load->view('templates/footer');
        redirect('admin/gigi','refresh');
    }
    public function hapusGigi($id){
        $this->db->delete('tbl_poli_gigi',array('id' => $id));
        redirect('admin/gigi');
        // var_dump( $this->db->delete('tbl_poli_gigi',array('id' => $id)));
        // die;
    }
    
    public function editGigi($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_gigi')->row();
        // var_dump($data['umum']);
        // die;
            
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('edit/e_umum');
       $this->load->view('templates/footer');
    }
    public function p_editG(){
       
        $id = $this->input->post('id');
        $idpoli = $this->input->post('iddtpasien');
        $nma = $this->input->post('nama');
        $anamenesa = $this->input->post('anamenesa');
        $diag = $this->input->post('diagnostic');
        $tensi = $this->input->post('tensi');
        $nadi = $this->input->post('nadi');
        $suhu = $this->input->post('suhu');
        $laju = $this->input->post('laju');
        $tinggi = $this->input->post('tinggi_badan');
        $berat = $this->input->post('berat_badan');
        $tingkat = $this->input->post('tingkat_kesadaran');
        $kepala = $this->input->post('kepala');
        $jantung = $this->input->post('jantung');
        $paru= $this->input->post('paru_paru');
        $perut = $this->input->post('perut');
        $adema = $this->input->post('adema');
        $icd = $this->input->post('icd');
        $planing = $this->input->post('planing');
        $tglkunj =$this->input->post('tanggal');
        $objek = array(
            'id'=>$id,
            'iddtpasien'=>$idpoli,
             'nama'=>$nma,
             'anamnesa' => $anamenesa,
             'physic_diagnostic' => $diag,
             'tensi' => $tensi,
             'nadi' => $nadi,
             'suhu' => $suhu,
             'laju_pernafasan' => $laju,
             'tinggi_badan' => $tinggi,
             'berat_badan' => $berat,
             'tingkat_kesadaran' => $tingkat,
             'kepala_leher' => $kepala,
             'jantung'=>$jantung,
             'paru_paru' => $paru,
             'perut' => $perut,
             'adema' => $adema,
             'ICD_X' => $icd,
             'planing' => $planing,
             'tanggal_kunjungan'=>$tglkunj,);


            $this->db->where('id',$id)->update('tbl_poli_gigi',$objek);
            redirect('admin/gigi', 'refresh');
        
    } 
    public function detailGigi($id){
        $data['title'] = 'Edit Data';
        $data['user']= $this->db->get_where('user',['email'=> 
        $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
       $data['umum'] = $this->db->where('id',$id)->get('tbl_poli_gigi')->row();
        // var_dump($data['umum']);
        // die;
            
       $this->load->view('templates/header');
       $this->load->view('templates/sidebar');
       $this->load->view('templates/topbar',$data);
       $this->load->view('detail/detailGigi');
       $this->load->view('templates/footer');
    }


    public function grafikGigi()
    {
        $data['title'] = 'Edit Data';
            $data['user']= $this->db->get_where('user',['email'=> 
            $this->session->userdata('email')])->row_array();
            // $data['pasien'] = $this->db->get('tbl_data_pasien')->result();
        //    $data['detailPasien'] = $this->db->where('id',$id)->get('tbl_data_pasien')->row();
            // var_dump($data['umum']);
            // die;
                
           $this->load->view('templates/header');
           $this->load->view('templates/sidebar');
           $this->load->view('templates/topbar',$data);
           $this->load->view('grafik/GrafikGigi');
           $this->load->view('templates/footer');
        }
}